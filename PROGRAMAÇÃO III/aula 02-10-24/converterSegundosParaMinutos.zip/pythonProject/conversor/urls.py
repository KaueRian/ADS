# conversor/urls.py
from django.urls import path
from .views import converter_segundos_para_minutos_segundos

urlpatterns = [
    path('', converter_segundos_para_minutos_segundos, name='converter_segundos_para_minutos_segundos'),
]
