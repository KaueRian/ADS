from django.shortcuts import render

# Create your views here.
from django.shortcuts import render


def converter_segundos_para_minutos_segundos(request):
    minutos = None
    if request.method == 'POST':
        try:
            segundos = int(request.POST.get('segundos', 0))
            # segundos = int(request.POST.get('segundos', 0))
            # Converter segundos para segundos
            minutos = segundos // 60
            segundos_restantes = segundos % 60

        except ValueError:
            minutos = "Entrada inválida."

    return render(request, 'converter.html', {'minutos': minutos, 'segundos_restantes': segundos_restantes})
