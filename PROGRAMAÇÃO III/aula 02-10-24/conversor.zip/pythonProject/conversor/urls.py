# conversor/urls.py
from django.urls import path
from .views import converter_horas_minutos

urlpatterns = [
    path('', converter_horas_minutos, name='converter_horas_minutos'),
]
