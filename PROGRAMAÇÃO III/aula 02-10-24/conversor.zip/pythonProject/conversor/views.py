from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

def converter_horas_minutos(request):
    resultado = None
    if request.method == 'POST':
        try:
            horas = int(request.POST.get('horas', 0))
            minutos = int(request.POST.get('minutos', 0))
            # Converter horas para minutos
            resultado = (horas * 60) + minutos
        except ValueError:
            resultado = "Entrada inválida."

    return render(request, 'converter.html', {'resultado': resultado})