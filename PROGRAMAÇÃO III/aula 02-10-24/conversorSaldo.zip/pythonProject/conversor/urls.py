# conversor/urls.py
from django.urls import path
from .views import converter_saldo

urlpatterns = [
    path('', converter_saldo, name='converter_saldo'),
]
