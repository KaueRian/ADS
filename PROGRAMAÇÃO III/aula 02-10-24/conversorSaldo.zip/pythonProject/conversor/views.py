from django.shortcuts import render

# Create your views here.
from django.shortcuts import render


def converter_saldo(request):
    resultado = None
    if request.method == 'POST':
        try:
            saldo = int(request.POST.get('saldo', 0))

            # minutos = int(request.POST.get('minutos', 0))
            # Converter saldo para minutos
            resultado = saldo * 1.20
        except ValueError:
            resultado = "Entrada inválida."

    return render(request, 'reajuste.html', {'resultado': resultado})
