"""
Claudinei de Oliveira - ptbr - __init__.py
"""
